'use strict';
import { HttpsProxyAgent } from 'https-proxy-agent';

// Content script file will run in the context of web page.
// With content script you can manipulate the web pages using
// Document Object Model (DOM).
// You can also pass information to the parent extension.

// We execute this script by making an entry in manifest.json file
// under `content_scripts` property

// For more information on Content Scripts,
// See https://developer.chrome.com/extensions/content_scripts

// Communicate with background file by sending a message
chrome.runtime.sendMessage(
  {
    type: 'GREETINGS',
    payload: {
      message: 'Hello, my name is Con. I am from ContentScript.',
    },
  },
  (response) => {
    console.log(response.message);
  }
);

// Listen for message
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'COUNT') {
    console.log(`Current count is ${request.payload.count}`);
  }

  // Send an empty response
  // See https://github.com/mozilla/webextension-polyfill/issues/130#issuecomment-531531890
  sendResponse({});
  return true;
});


//process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = 0;

(async () => {
    const proxyHost = '63.35.64.177';
    const proxyPort = 3128;
    const proxyUrl = `http://${proxyHost}:${proxyPort}`;
    const targetUrl = `https://www.virustotal.com/api/v3/domains/17ebook.com`;


    const proxyAgent = new HttpsProxyAgent(proxyUrl);
    const options = {method: 'GET', headers: {
        accept: 'application/json',
        'x-apikey': '5331fe0a95c668061aa4cb32644f877639b63274867a2e9baa4d169736ab6013'
    }};

    // Fetch the target website using the proxy agent
    fetch(targetUrl, options, { agent: proxyAgent })
        .then(res => res.json())
        .then(function(json){
            const vt = json['data']['attributes']['total_votes'];
            const lt = json['data']['attributes']['last_analysis_stats'];
            const p = vt['harmless']*3 - vt['malicious'] - lt['malicious']*5;
            console.log(p);
        })
        .catch(err => console.error(err));
})();

